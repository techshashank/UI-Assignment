
  //load data into table  
function getdatatable ()
       {
    
        var url = 'http://merlinatwork.com/ascentapidemo/api/Course/';
$.ajax({
    url: url,
    type: 'GET',
    async:false,
    contentType: 'json',
    headers: {'Authorization': 'Bearer 1ZNLGDo1qCNux7tKWHDRHJLtJDoAy9PUAQdEq_s4nCoA5PNnqYSanlL0hK8qAbFK9j7e6TFIjzfoGZYMwOdXAqz9S7nnJbsoXpD_kaLsy4683z6ty-qmX0D9UFVpy8LqNcba2PMf9EsFOYGmNc9O5kMZ3ntfwyuaRZzCvcjDXjSl7lfIrMyvC0ufd-u8gT5sISeyf-aiv_Asast-4yQw3lUt_5T_gB1qwkdLdiwjyD6QZr7yCOrZa0snXArVNrA8MLdXiv58matUeX_-DdIan4kyicmEbTU3AX7LdljA5vGq9XVRd5W4qKjCuQbuOqo8rO5IX_a7w3Ksdcpg82fkmtGlrYh-HqumpCSuhz0dB4eoxuL8L70N-nJNXSmzgDnK-6NFv2Tj-6Erp8Uo0AdLN9E5w09-9ZcYksEg1jHdLE4'},
    success: function(data) {
      // console.log(data);
       var data = JSON.parse(JSON.stringify(data));
       var tr;
        for (var i = 0; i < data.length; i++) {
            tr = $('<tr/>');
            tr.append("<td><input type='checkbox' id='"+data[i].CourseID+"'></td>")
            tr.append("<td>" + data[i].Name + "</td>");
            tr.append("<td>" + data[i].CourseCategory + "</td>");
            tr.append("<td>" + data[i].CourseCategoryID + "</td>");
           
            tr.append("<td>" + data[i].CourseType + "</td>");
            tr.append("<td>" + data[i].CourseTypeID + "</td>");
          
            tr.append("<td>" + data[i].CourseCode + "</td>");
            tr.append("<td>" + data[i].Duration + "</td>");
            tr.append("<td>" + data[i].EstimatedCostPerHead + "</td>");
            $('#tbdata').append(tr);
        }

    
    },
   
});   
       };  

getdatatable();       
// add data into table 
 function addCourse(e)
 {

  $('#addmodal').modal('hide');
           e.preventDefault();           
           var url = 'http://merlinatwork.com/ascentapidemo/api/Course/';
           
           var name =$('#txt_name').val();
           var coursecategory =$('#txt_coursecat').val();
           var coursecategoryid =$('#txt_coursecatid').val();
           var coursetype = $('#txt_coursetyp').val();
           var coursetypeid = $('#txt_coursetypid').val();
           var coursecode = $('#txt_coursecode').val();
           var duration =$('#txt_duration').val();
           var estimatedcostperhead = $('#txt_estimation').val();
           
           var jsondata = {Name: name, CourseCategory: coursecategory, CourseCategoryID:coursecategoryid, CourseType: coursetype, CourseTypeID:coursetypeid, CourseCode: coursecode, Duration: duration, EstimatedCostPerHead:estimatedcostperhead };
          
    $.ajax({
                url: url,
                type: 'POST',
                async:false,
                contentType: 'application/json',
                dataType:'json',
                data:JSON.stringify(jsondata),
                headers: {'Authorization': 'Bearer 1ZNLGDo1qCNux7tKWHDRHJLtJDoAy9PUAQdEq_s4nCoA5PNnqYSanlL0hK8qAbFK9j7e6TFIjzfoGZYMwOdXAqz9S7nnJbsoXpD_kaLsy4683z6ty-qmX0D9UFVpy8LqNcba2PMf9EsFOYGmNc9O5kMZ3ntfwyuaRZzCvcjDXjSl7lfIrMyvC0ufd-u8gT5sISeyf-aiv_Asast-4yQw3lUt_5T_gB1qwkdLdiwjyD6QZr7yCOrZa0snXArVNrA8MLdXiv58matUeX_-DdIan4kyicmEbTU3AX7LdljA5vGq9XVRd5W4qKjCuQbuOqo8rO5IX_a7w3Ksdcpg82fkmtGlrYh-HqumpCSuhz0dB4eoxuL8L70N-nJNXSmzgDnK-6NFv2Tj-6Erp8Uo0AdLN9E5w09-9ZcYksEg1jHdLE4'},
                success: function(data){
                   console.log(data);
                   $('#tbdata').empty();
                   getdatatable();
                
      
                },
                error:function(result){
                   console.log(result);
                },
              
              });
          
            };   
 //addCourse();

 //edit 
 var selected_id="";
 function getfieldid(e){

       e.preventDefault();
      
      
       $.each($("#tbdata input[type=checkbox]:checked"), function(){

      selected_id= this.id;
      
 //alert(id);
       });
       var url= "http://merlinatwork.com/ascentapidemo/api/Course/"+selected_id;
       $.ajax({
        url: url,
                type: 'GET',
                async:false,
                contentType: 'application/json',
                dataType:'json',
              
                headers: {'Authorization': 'Bearer 1ZNLGDo1qCNux7tKWHDRHJLtJDoAy9PUAQdEq_s4nCoA5PNnqYSanlL0hK8qAbFK9j7e6TFIjzfoGZYMwOdXAqz9S7nnJbsoXpD_kaLsy4683z6ty-qmX0D9UFVpy8LqNcba2PMf9EsFOYGmNc9O5kMZ3ntfwyuaRZzCvcjDXjSl7lfIrMyvC0ufd-u8gT5sISeyf-aiv_Asast-4yQw3lUt_5T_gB1qwkdLdiwjyD6QZr7yCOrZa0snXArVNrA8MLdXiv58matUeX_-DdIan4kyicmEbTU3AX7LdljA5vGq9XVRd5W4qKjCuQbuOqo8rO5IX_a7w3Ksdcpg82fkmtGlrYh-HqumpCSuhz0dB4eoxuL8L70N-nJNXSmzgDnK-6NFv2Tj-6Erp8Uo0AdLN9E5w09-9ZcYksEg1jHdLE4'},
                success: function(data){
                $('#edittxt_name').val(data.Name);
           $('#edittxt_coursecat').val(data.CourseCategory);
           $('#edittxt_coursecatid').val(data.CourseCategoryID);
           $('#edittxt_coursetyp').val(data.CourseType);
           $('#edittxt_coursetypid').val(data.CourseTypeID);
           $('#edittxt_coursecode').val(data.CourseCode);
           $('#edittext_duration').val(data.Duration);
           $('#edittxt_estimation').val(data.EstimatedCostPerHead);

       $('#editmodal').modal('show');
                },

                 error:function(result){
                   console.log(result);
                },
              
       });

 };


 function updateCourse(e)
 {

  $('#editmodal').modal('hide');
           e.preventDefault();           
           var url = 'http://merlinatwork.com/ascentapidemo/api/Course/'+selected_id;
           var frm = $('#myForm');
           var name =$('#edittxt_name').val();
           var coursecategory =$('#edittxt_coursecat').val();
           var coursecategoryid =$('#edittxt_coursecatid').val();
           var coursetype = $('#edittxt_coursetyp').val();
           var coursetypeid = $('#edittxt_coursetypid').val();
           var coursecode = $('#edittxt_coursecode').val();
           var duration =$('#edittxt_duration').val();
           var estimatedcostperhead = $('#edittxt_estimation').val();
           
           var jsondata = {Name: name, CourseCategory: coursecategory, CourseCategoryID:coursecategoryid, CourseType: coursetype, CourseTypeID:coursetypeid, CourseCode: coursecode, Duration: duration, EstimatedCostPerHead:estimatedcostperhead };
          

   
    $.ajax({
                url: url,
                type:'PUT',
                async:false,
                contentType: 'application/json',
                dataType:'json',
                data:JSON.stringify(jsondata),
                headers: {'Authorization': 'Bearer 1ZNLGDo1qCNux7tKWHDRHJLtJDoAy9PUAQdEq_s4nCoA5PNnqYSanlL0hK8qAbFK9j7e6TFIjzfoGZYMwOdXAqz9S7nnJbsoXpD_kaLsy4683z6ty-qmX0D9UFVpy8LqNcba2PMf9EsFOYGmNc9O5kMZ3ntfwyuaRZzCvcjDXjSl7lfIrMyvC0ufd-u8gT5sISeyf-aiv_Asast-4yQw3lUt_5T_gB1qwkdLdiwjyD6QZr7yCOrZa0snXArVNrA8MLdXiv58matUeX_-DdIan4kyicmEbTU3AX7LdljA5vGq9XVRd5W4qKjCuQbuOqo8rO5IX_a7w3Ksdcpg82fkmtGlrYh-HqumpCSuhz0dB4eoxuL8L70N-nJNXSmzgDnK-6NFv2Tj-6Erp8Uo0AdLN9E5w09-9ZcYksEg1jHdLE4'},
                success: function(data){
                   console.log(data);
                   $('#tbdata').empty();
                   getdatatable();
                
      
                },
                error:function(result){
                   console.log(result);
                },
              
              });
          
            };   
 function deletecourse(e){
   e.preventDefault();

   if (confirm('Are you sure want to delete this course?')) {

    $.each($("#tbdata input[type=checkbox]:checked"), function(){

selected_id= this.id;


 });

    var url = 'http://merlinatwork.com/ascentapidemo/api/Course/'+selected_id;
    $.ajax({
        url: url,
                type: 'DELETE',
                async:false,
                contentType: 'application/json',
                dataType:'json',
              
                headers: {'Authorization': 'Bearer 1ZNLGDo1qCNux7tKWHDRHJLtJDoAy9PUAQdEq_s4nCoA5PNnqYSanlL0hK8qAbFK9j7e6TFIjzfoGZYMwOdXAqz9S7nnJbsoXpD_kaLsy4683z6ty-qmX0D9UFVpy8LqNcba2PMf9EsFOYGmNc9O5kMZ3ntfwyuaRZzCvcjDXjSl7lfIrMyvC0ufd-u8gT5sISeyf-aiv_Asast-4yQw3lUt_5T_gB1qwkdLdiwjyD6QZr7yCOrZa0snXArVNrA8MLdXiv58matUeX_-DdIan4kyicmEbTU3AX7LdljA5vGq9XVRd5W4qKjCuQbuOqo8rO5IX_a7w3Ksdcpg82fkmtGlrYh-HqumpCSuhz0dB4eoxuL8L70N-nJNXSmzgDnK-6NFv2Tj-6Erp8Uo0AdLN9E5w09-9ZcYksEg1jHdLE4'},
                success: function(data){
                 alert ('Successfuly Deleted')

                },
                error:function(result){
                   console.log(result);
                },
    });


   }

 };
